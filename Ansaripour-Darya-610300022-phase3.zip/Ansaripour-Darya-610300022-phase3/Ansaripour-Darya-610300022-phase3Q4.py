import pandas as pd
df = pd.read_csv('Datas.csv')



''' first question: '''

hyundaipeugeot = df[(df.company=='hyundai') | (df.company=='peugeot')]
hyundaipeugeot = hyundaipeugeot.drop_duplicates(subset='car', keep='first')
print(hyundaipeugeot[['company', 'car']].to_string())




''' second question: '''

last5years = df[((2017<=df.year) & (df.year<=2022)) | ((1395<=df.year) & (df.year<=1400))]
print(len(last5years))




''' third question: '''

p206sd = df[(df.company=='peugeot') & (df.car=='206sd')]
print(p206sd.tream.describe())




''' fourth question: '''

df2=pd.read_csv('Datas.csv')
df2['year'].where(df2['year'] > 1400, df2['year']+621 , inplace=True)
df2['years'] = 2022-df2['year']
df2['avr'] = df2['kilometer']//df2['years']
car = df2['avr'].idxmax()
print(df2.loc[car])





''' fifth question: '''

prices = df[['company', 'price']]
prices = prices[(prices.price!=-1) & (prices.price!=-2)]
prices = prices.groupby('company').mean()
comp = prices['price'].idxmax()
print(comp)



''' sixth question: '''     

print(df.car.describe())




'''seventh question: '''   

p206_8592 = df[(df.car=='206') & ((1385<=df.year) & (df.year<=1392)) & (df.price!=-1) & (df.price!=-2)]
mean1 = p206_8592.price.mean()

p206_9300 = df[(df.car=='206') & ((1393<=df.year) & (df.year<=1400)) & (df.price!=-1) & (df.price!=-2)]
mean2 = p206_9300.price.mean()
print(mean2-mean1)

