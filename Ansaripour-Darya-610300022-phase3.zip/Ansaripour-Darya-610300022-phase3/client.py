import socket
import json
from bs4 import BeautifulSoup
from requests import Session


ses=Session()
datas=[]

rs=ses.post("http://utproject.ir/bp/login.php",data={"username":"610300022","password":"19166287669521964895"})

for j in range(500):
    res=ses.get(f'http://utproject.ir/bp/Cars/page{j}.php')
    res.encoding='utf-8'

    soup=BeautifulSoup(res.text,'html.parser')
    l=soup.find_all(class_='car-list-item-li list-data-main')

    for i in range(len(l)):
        d={}

        company=l[i]['data-url'].split('-')[2]
        d['company']=company

        car=l[i]['data-url'].split('-')[3]
        d['car']=car

        tream=l[i]['data-url'].split('-')[4:-1]
        tream='-'.join(tream)
        d['tream']=tream

        try:
            kilometer=int((l[i].find(class_='car-func-details').span.text).split()[1].replace(',', ''))
        except:
            kilometer=0
        d['kilometer']=kilometer

        year=int(l[i]['data-url'].split('-')[-1])
        d['year']=year

        try:
            price=int((l[i].find(class_='cost single-price').span.text).strip().replace(',', ''))
        except:
            try:
                price=l[i].find(class_='cost small').span.text
                price=-2
            except:
                try:
                    price=int(l[i].find(class_='cost blured single-price').span.text.strip().replace(',', ''))
                except:
                    price=l[i].find(class_='cost installment-cost')
                    price=-1
        d['price']=price
        datas.append(d)
        
    print(j)


def num_to_string(num):
    string=''
    r=0
    while num>0 :
        r=num%26
        if r==0:
            string+='Z'
            num-=1
        else:
            string+=chr(r+ord('A')-1)
        num//=26
    return(string[::-1])


finalmatrix=[]
cmnds=[f'create(data,6,{len(datas)+1})','context(data)']
titles=['company', 'car', 'tream', 'kilometer', 'year' , 'price']

for i in range(6):
    cmnd= f'{num_to_string(i+1)}1 = {titles[i]}'
    cmnds.append(cmnd)
for j in range(len(datas)):
    for i in range(6):
        value=datas[j][titles[i]]
        cmnd=f'{num_to_string(i+1)}{j+2} = {value}'
        cmnds.append(cmnd)
cmnds.append("#")



class Client:
    def __init__(self, port: int = 5050, max_req_len: int = 50):
        self._max_req_len = max_req_len
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.sock.connect(("localhost", port))
        

    def run(self):
        for command in cmnds:                      
            if command.startswith("#"):                             
                self.sendReq({"req_type": "get_results"})
            else:
                self.sendReq({"req_type": "command",
                            "command_str": command})

            rs1=self.getRes()
            if rs1!= {"success": True}:
                rs2=self.getRes()
                rs3=self.getRes()
                rs4=self.getRes()
                rs5=self.getRes()
                rs6=self.getRes()
                rs7=self.getRes()
                rs8=self.getRes()
                rs9=self.getRes()
                rs10=self.getRes()
                finalmatrix=rs1["result"]+rs2["result"]+rs3["result"]+rs4["result"]+rs5["result"]+rs6["result"]+rs7["result"]+rs8["result"]+rs9["result"]+rs10["result"]
                print(finalmatrix)



    def getRes(self):
        req_len = int(self.sock.recv(self._max_req_len).decode('utf-8'))
        return json.loads(self.sock.recv(req_len).decode('utf-8'))


    def sendReq(self, res_dic):
        res_str = json.dumps(res_dic)
        res_str = f"{len(res_str):<{self._max_req_len}}" + res_str
        print(f'sending: {res_str}')
        self.sock.send(bytes(res_str, encoding='utf-8'))

if __name__ == "__main__":
    client = Client()
    client.run()

# f=open('Datas.csv', 'w')
# for row in finalmatrix:
#     row=','.join(row)
#     f.write(row)
#     f.write('\n')
# f.close()

